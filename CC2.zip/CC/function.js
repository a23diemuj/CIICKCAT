
contador1=0;
contador2=0;
document.getElementById("contador1").innerHTML=contador1;
document.getElementById("contador2").innerHTML=contador2;




document.getElementById("dog1").addEventListener("click", function(){
    contador1++;
    document.getElementById("contador1").innerHTML=contador1;


})


document.getElementById("dog2").addEventListener("click", function(){
    contador2++;
    document.getElementById("contador2").innerHTML=contador2;
    
    
    })

