
contador=0;
document.getElementById("contador").innerHTML=contador;


document.getElementById("dog1").addEventListener("click", function(){
contador++;
document.getElementById("contador").innerHTML=contador;


})

